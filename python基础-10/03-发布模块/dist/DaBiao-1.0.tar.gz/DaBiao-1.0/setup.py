from distutils.core import setup

setup(name="DaBiao", version="1.0", description="DaBiao's module", author="DaBiao", py_modules=['Testmsg.sendmsg',"Testmsg.recvmsg"])
